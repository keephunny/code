package ext.opensource.netty.client.mqtt.common;

/**
 * @author ben
 * @Title: basic
 * @Description:
 **/
public interface ClientEvent {
	/**
	 * 事件处理
	 */
	public void process();
}
