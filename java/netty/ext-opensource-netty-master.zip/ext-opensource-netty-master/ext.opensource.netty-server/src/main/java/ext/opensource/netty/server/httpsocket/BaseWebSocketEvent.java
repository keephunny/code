package ext.opensource.netty.server.httpsocket;

/**
 * @author ben
 * @Title: basic
 * @Description:
 **/

public abstract class BaseWebSocketEvent implements WebSocketEvent {
}
