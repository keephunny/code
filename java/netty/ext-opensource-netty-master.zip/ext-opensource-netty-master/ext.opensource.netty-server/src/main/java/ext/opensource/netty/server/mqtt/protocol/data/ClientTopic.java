package ext.opensource.netty.server.mqtt.protocol.data;

/**
 * @author ben
 * @Title: basic
 * @Description:
 **/

public class ClientTopic extends BaseDataInMap<String, String> {
	private static final long serialVersionUID = 1L;

	public ClientTopic() {
		super("");
	}

	
}
