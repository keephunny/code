package ext.opensource.netty.common.api;

/**
 * @author ben
 * @Title: basic
 * @Description:
 **/
public interface SocketApplication {
	
	/**
	 * close socket server 
	 */
	public void shutdown();
}
