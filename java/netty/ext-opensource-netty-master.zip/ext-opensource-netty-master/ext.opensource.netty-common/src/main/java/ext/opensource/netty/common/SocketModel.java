package ext.opensource.netty.common;

/**
 * @author ben
 * @Title: basic
 * @Description:
 **/

public enum SocketModel {
	/**
	 * 阻塞
	 */
	BLOCK, 
	
	/**
	 * 非阻塞
	 */
	UNBOLOCK
}
