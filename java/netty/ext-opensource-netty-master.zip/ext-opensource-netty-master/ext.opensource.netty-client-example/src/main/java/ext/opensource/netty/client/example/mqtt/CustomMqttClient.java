package ext.opensource.netty.client.example.mqtt;

import ext.opensource.netty.client.mqtt.MqttClient;

/**
 * @author ben
 * @Title: basic
 * @Description:
 **/

public class CustomMqttClient implements MqttClientCustomInit {
	
	@Override
	public void init(MqttClient nettyClient) {
		
	}
}
