package cn.edu.ncu.exception;

public class EmptyListException extends Throwable {
}
