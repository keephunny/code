package cn.edu.ncu.common;

public class StringUtil {
    public static boolean hasText(String s){
        return s != null && !s.isEmpty();
    }
}
